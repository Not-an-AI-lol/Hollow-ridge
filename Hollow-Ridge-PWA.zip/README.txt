Hollow Ridge PWA
1. Unzip this folder.
2. Go to https://app.netlify.com/drop and drag the whole folder onto the page (or upload it to GitHub Pages).
3. Open the address it gives you on your phone or computer, then use "Install" / "Add to Home Screen".
Party play uses a public internet relay; the game itself runs offline after the first visit.
