# Hollow Ridge multiplayer server

This is the small server that lets everyone play together, whichever version of the game they use
(artifact, offline file or installed app). It relays player positions and party codes, chat messages,
and keeps the leaderboard.

## Files (all four go in one folder / GitHub repo)
- `server.js`    the server
- `package.json` tells the host to install `ws` and how to start
- `render.yaml`  Render settings (free plan, health check)
- `.gitignore`   keeps junk out of the repo

## Put it online with Render (free to start)
1. Create a free GitHub account and a new repository called `hollow-ridge-server`.
2. On the repository page choose **Add file > Upload files** and upload the four files above. Commit.
3. Create a free account at render.com and connect your GitHub account.
4. Choose **New > Blueprint**, pick the repository and press **Apply**. (Or **New > Web Service**:
   build command `npm install`, start command `node server.js`, instance type Free.)
5. After a couple of minutes Render shows an address like `https://hollow-ridge-server.onrender.com`.
   Opening it in a browser should say "Hollow Ridge server is running".
6. In the game open **Friends**, scroll to **Game server**, paste that address and press **Connect**.
   Everyone who plays together pastes the same address.

## Things to know
- Free Render servers go to sleep after about 15 minutes with nobody connected and take around a minute to
  wake up. The first player to connect just waits. The paid Starter plan (about $7 a month) stays awake.
- The leaderboard is stored in a file. On the free plan the disk is wiped when the server restarts or
  redeploys, so the leaderboard can reset. A paid plan with a disk keeps it.
- Fly.io and Railway also work: any host that runs `node server.js` and allows WebSockets.
- Test on your own computer: `npm install`, `node server.js`, then paste `ws://localhost:8080` into the game.
- Scores are reported by each player's game, so a determined cheater could fake them.
